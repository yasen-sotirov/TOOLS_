class TestResult:
    PASS = 'pass'
    FAIL = 'fail'
