
class ApplicationError(Exception):
    '''
    Custom class for application-specific exceptions
    '''
    pass
