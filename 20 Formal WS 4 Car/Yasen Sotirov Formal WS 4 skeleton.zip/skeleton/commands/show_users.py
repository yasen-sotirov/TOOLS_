
class ShowUsersCommand():

    def execute(self, params):
        # Todo: Finish the implementation 
        raise NotImplementedError()
