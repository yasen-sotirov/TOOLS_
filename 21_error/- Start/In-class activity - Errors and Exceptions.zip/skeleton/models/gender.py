from enum import Enum


class Gender(Enum):
    MEN = 'Men'
    WOMEN = 'Women'
    UNISEX = 'Unisex'
