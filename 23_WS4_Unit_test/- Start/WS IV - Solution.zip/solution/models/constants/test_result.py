from enum import Enum


class TestResult(Enum):
    PASS = 'pass'
    FAIL = 'fail'
